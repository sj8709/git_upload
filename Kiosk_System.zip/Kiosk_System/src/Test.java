import java.awt.Dimension;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.*;


public class Test extends JFrame{

	public Test(){
		super("Test"); // JFrame의 생성자에 값을 입력하면 윈도창에 해당 값이 입력됩니다.
                JPanel jp = new JPanel(); // 패널 초기화
                JButton jb1 = new JButton("버튼"); // 버튼 초기화
                JButton jb2 = new JButton("버튼"); // 버튼 초기화
                jp.setBackground(new java.awt.Color(255, 0, 255));
		
		jp.add(jb1); // jp라는 패널에 jb라는 버튼 추가
		add(jp); // JFrame에 jp라는 패널 추가
		
		setSize(400, 300); // 윈도우의 크기 가로x세로
		setVisible(true); // 창을 보여줄떄 true, 숨길때 false
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // x 버튼을 눌렀을때 종료
                jb2.setPreferredSize(new Dimension(450, 208));
                System.out.print(jp.add(jb2)); // jp라는 패널에 jb라는 버튼 추가
	}

	public static void main(String[] args){
		new Test();
	} 
}