
import java.io.IOException;
import java.sql.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pc
 */
public class DBConnection {
        public static Connection getConnection() {
            Connection conn = null;
            try {
                String user = "kiosk_manager";
                String pw = "201444034";
                String url = "jdbc:oracle:thin:@localhost:1521";
                
                Class.forName("oracle.jdbc.driver.OracleDriver");
                conn = DriverManager.getConnection(url, user, pw);
                
            } catch (ClassNotFoundException e) {
                System.out.println("DB 드라이버 로딩 실패 : "+e.toString());
            } catch (SQLException e) {
                System.out.println("DB 접속실패 : " + e.toString());
            } catch (Exception e) {
                e.printStackTrace();
            }
            return conn;
        }
        
        public static ResultSet queryExecute(String strQuery) throws SQLException {
            Connection conn = DBConnection.getConnection();        // DB에 연결
            PreparedStatement pstm = conn.prepareStatement(strQuery);     // SQL문을 날림
            ResultSet rs = pstm.executeQuery();                   // 쿼리문의 결과를 담음
            return rs;                                  // 결과를 반환
        }
}
